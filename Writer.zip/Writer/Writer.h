#ifndef WRITER_H_INCLUDED
#define WRITER_H_INCLUDED
#include <string>
using namespace std;
class Writer
{
    public:
        Writer();
        Writer(string);
        string getErrorMsg();
        bool write(string);
        bool clean();
    private:
        string def_loc, error_msg;
};


#endif // WRITER_H_INCLUDED
