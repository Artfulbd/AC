#include "btsmotordriver.h"

BTS7960MotorDriver::BTS7960MotorDriver(int p1, int p2, int p3, int p4)
{
    M_pin1 = p1;

    M_pin2 = p2;

    //M_RPWMPin = p3;
    M_RPWMPin = p3;
	
	M_LPWMPin = p4;
	
    pinMode(M_pin1, OUTPUT);
    
    pinMode(M_pin2, OUTPUT);
}

BTS7960MotorDriver::~BTS7960MotorDriver()
{
	
}

void BTS7960MotorDriver::Ready()
{
    digitalWrite(M_pin1, HIGH);
    digitalWrite(M_pin2, HIGH);
}


void BTS7960MotorDriver::TurnLeft(int s)
{
	M_Speed = s;
    analogWrite(M_LPWMPin, M_Speed);
}

void BTS7960MotorDriver::TurnRight(int s)
{
	M_Speed = s;
    analogWrite(M_RPWMPin, M_Speed);
}

void BTS7960MotorDriver::Stop()
{
	digitalWrite(M_LPWMPin, LOW);
	digitalWrite(M_RPWMPin, LOW);
    digitalWrite(M_pin1, LOW);
    digitalWrite(M_pin2, LOW);
}

