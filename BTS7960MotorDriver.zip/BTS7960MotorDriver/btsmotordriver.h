#ifndef BTS7960_H
#define BTS7960_H

#include "Arduino.h"

#define LOWER_ANALOG_LIMIT 0

class BTS7960MotorDriver
{
private:
    //int M_pin1 , M_pin2, M_PWMPin;
	int M_pin1 , M_pin2, M_RPWMPin, M_LPWMPin;

    int M_Speed;

    int turnDirection;

public:

    BTS7960MotorDriver(int, int, int, int);

    ~BTS7960MotorDriver();

    void Ready();

    void TurnLeft(int);
	
	void TurnRight(int);
    
    void Stop();

};


#endif // BTS7960_H
