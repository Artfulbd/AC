#include "Writer.h"
#include <fstream>
Writer::Writer()
{
    def_loc = "keep.dat";
}
Writer::Writer(string loc)
{
    def_loc = loc;
}
bool Writer::write(string data)
{
    ofstream writefile; //writing
    ifstream readfile;
    string line;
    writefile.open (def_loc);
    writefile << data;
    writefile.close();


    readfile.open(def_loc);
    if (readfile.is_open())getline (readfile,line);
    else
    {
        error_msg = "Problem on file system.!!";
        return false;
    }
    if(line == data)return true;
    error_msg = "Problem on library.!!";
    return false;
}
bool Writer::clean()
{
    ofstream writefile; //writing null
    writefile.open (def_loc);
    writefile << "";
    writefile.close();
}
string Writer::getErrorMsg()
{
    return ( error_msg == "") ? "No error " : error_msg;
}



